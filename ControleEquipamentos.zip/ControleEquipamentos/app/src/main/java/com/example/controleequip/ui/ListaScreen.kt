package com.example.controleequip.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.controleequip.EquipamentoViewModel
import com.example.controleequip.data.Equipamento
import com.example.controleequip.data.TipoEquipamento
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaScreen(
    vm: EquipamentoViewModel,
    onNovo: () -> Unit,
    onEditar: (Equipamento) -> Unit
) {
    val itens by vm.itens.collectAsState()
    val busca by vm.busca.collectAsState()
    val filtro by vm.filtroTipo.collectAsState()
    val context = LocalContext.current
    var paraExcluir by remember { mutableStateOf<Equipamento?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Equipamentos (${itens.size})") },
                actions = {
                    IconButton(onClick = {
                        vm.exportar { intent ->
                            if (intent == null) {
                                Toast.makeText(context, "Nada para exportar.", Toast.LENGTH_SHORT).show()
                            } else {
                                context.startActivity(intent)
                            }
                        }
                    }) { Icon(Icons.Default.Share, contentDescription = "Exportar CSV") }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNovo,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Novo") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = busca,
                onValueChange = { vm.busca.value = it },
                label = { Text("Buscar por MAC, contrato, serial…") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            )

            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = filtro == null,
                        onClick = { vm.filtroTipo.value = null },
                        label = { Text("Todos") }
                    )
                }
                items(TipoEquipamento.entries.toList()) { t ->
                    FilterChip(
                        selected = filtro == t,
                        onClick = { vm.filtroTipo.value = if (filtro == t) null else t },
                        label = { Text(t.rotulo) }
                    )
                }
            }

            if (itens.isEmpty()) {
                Text(
                    "Nenhum equipamento cadastrado.\nToque em “Novo” e escaneie a etiqueta.",
                    modifier = Modifier.padding(24.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }

            LazyColumn(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(itens, key = { it.id }) { e ->
                    ItemEquipamento(
                        e = e,
                        onClick = { onEditar(e) },
                        onExcluir = { paraExcluir = e }
                    )
                }
            }
        }
    }

    paraExcluir?.let { e ->
        AlertDialog(
            onDismissRequest = { paraExcluir = null },
            title = { Text("Excluir equipamento?") },
            text = { Text("${e.tipoEnum.rotulo} • contrato ${e.contrato}") },
            confirmButton = {
                TextButton(onClick = { vm.excluir(e); paraExcluir = null }) { Text("Excluir") }
            },
            dismissButton = {
                TextButton(onClick = { paraExcluir = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun ItemEquipamento(e: Equipamento, onClick: () -> Unit, onExcluir: () -> Unit) {
    val data = remember(e.criadoEm) {
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(e.criadoEm))
    }
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(e.tipoEnum.rotulo, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (e.mac.isNotEmpty()) {
                    Text("MAC: ${e.mac}", fontFamily = FontFamily.Monospace)
                }
                if (e.serial.isNotEmpty()) {
                    Text(
                        (if (e.tipoEnum == TipoEquipamento.CHIP) "ICCID: " else "Serial: ") + e.serial,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text("Contrato: ${e.contrato}")
                if (e.observacao.isNotEmpty()) {
                    Text(e.observacao, style = MaterialTheme.typography.bodySmall)
                }
                Text(data, style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onExcluir) {
                Icon(Icons.Default.Delete, contentDescription = "Excluir")
            }
        }
    }
}
