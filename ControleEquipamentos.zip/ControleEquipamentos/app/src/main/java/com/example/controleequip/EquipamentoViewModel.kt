package com.example.controleequip

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.controleequip.data.AppDatabase
import com.example.controleequip.data.Equipamento
import com.example.controleequip.data.TipoEquipamento
import com.example.controleequip.util.CsvExporter
import com.example.controleequip.util.MacUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EquipamentoViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    val busca = MutableStateFlow("")
    val filtroTipo = MutableStateFlow<TipoEquipamento?>(null)

    val itens = combine(dao.todos(), busca, filtroTipo) { lista, q, tipo ->
        val termo = q.trim().lowercase()
        lista.filter { e ->
            (tipo == null || e.tipoEnum == tipo) &&
                (termo.isEmpty() ||
                    e.mac.lowercase().contains(termo) ||
                    e.mac.replace(":", "").lowercase().contains(termo) ||
                    e.serial.lowercase().contains(termo) ||
                    e.contrato.lowercase().contains(termo) ||
                    e.observacao.lowercase().contains(termo))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Valida e grava. Chama onErro com a mensagem ou onOk quando salvou. */
    fun salvar(e: Equipamento, onErro: (String) -> Unit, onOk: () -> Unit) {
        viewModelScope.launch {
            val tipo = e.tipoEnum
            val contrato = e.contrato.trim()
            val serial = e.serial.trim()

            if (contrato.isEmpty()) {
                onErro("Informe o número do contrato."); return@launch
            }

            var mac = ""
            if (tipo == TipoEquipamento.CHIP) {
                if (serial.isEmpty()) {
                    onErro("Informe o ICCID do chip."); return@launch
                }
            } else {
                mac = MacUtils.normalizar(e.mac) ?: run {
                    onErro("MAC inválido. Use 12 dígitos hexadecimais (ex.: AA:BB:CC:DD:EE:FF).")
                    return@launch
                }
                if (dao.contarMac(mac, e.id) > 0) {
                    onErro("Este MAC já está cadastrado."); return@launch
                }
            }

            val final = e.copy(
                mac = mac, serial = serial, contrato = contrato,
                observacao = e.observacao.trim()
            )
            if (final.id == 0L) dao.inserir(final) else dao.atualizar(final)
            onOk()
        }
    }

    fun excluir(e: Equipamento) {
        viewModelScope.launch { dao.excluir(e) }
    }

    /** Exporta tudo que está cadastrado (ignora filtros da tela). */
    fun exportar(onPronto: (Intent?) -> Unit) {
        viewModelScope.launch {
            val todos = dao.todosAgora()
            if (todos.isEmpty()) onPronto(null)
            else onPronto(CsvExporter.criarIntent(getApplication(), todos))
        }
    }
}
