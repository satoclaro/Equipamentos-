package com.example.controleequip.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.example.controleequip.EquipamentoViewModel
import com.example.controleequip.data.Equipamento
import com.example.controleequip.data.TipoEquipamento
import com.example.controleequip.util.MacUtils

private enum class Alvo { MAC, SERIAL, CONTRATO }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormScreen(
    vm: EquipamentoViewModel,
    inicial: Equipamento?,
    onVoltar: () -> Unit
) {
    var tipo by rememberSaveable { mutableStateOf(inicial?.tipo ?: TipoEquipamento.EMTA.name) }
    var mac by rememberSaveable { mutableStateOf(inicial?.mac ?: "") }
    var serial by rememberSaveable { mutableStateOf(inicial?.serial ?: "") }
    var contrato by rememberSaveable { mutableStateOf(inicial?.contrato ?: "") }
    var obs by rememberSaveable { mutableStateOf(inicial?.observacao ?: "") }
    var erro by rememberSaveable { mutableStateOf<String?>(null) }
    var alvo by rememberSaveable { mutableStateOf<Alvo?>(null) }

    val ehChip = TipoEquipamento.de(tipo) == TipoEquipamento.CHIP

    BackHandler {
        if (alvo != null) alvo = null else onVoltar()
    }

    val alvoAtual = alvo
    if (alvoAtual != null) {
        ScannerScreen(
            titulo = when (alvoAtual) {
                Alvo.MAC -> "Aponte para o código de barras do MAC"
                Alvo.SERIAL -> if (ehChip) "Aponte para o ICCID do chip" else "Aponte para o número de série"
                Alvo.CONTRATO -> "Aponte para o código do contrato"
            },
            onResultado = { lido ->
                when (alvoAtual) {
                    Alvo.MAC -> mac = MacUtils.normalizar(lido) ?: lido.trim()
                    Alvo.SERIAL -> serial = lido.trim()
                    Alvo.CONTRATO -> contrato = lido.trim()
                }
                erro = null
                alvo = null
            },
            onFechar = { alvo = null }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (inicial == null) "Novo equipamento" else "Editar equipamento") },
                navigationIcon = {
                    IconButton(onClick = onVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Tipo", style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TipoEquipamento.entries.toList()) { t ->
                    FilterChip(
                        selected = tipo == t.name,
                        onClick = { tipo = t.name; erro = null },
                        label = { Text(t.rotulo) }
                    )
                }
            }

            if (!ehChip) {
                CampoComScan(
                    valor = mac,
                    onChange = { mac = it },
                    rotulo = "MAC",
                    dica = "AA:BB:CC:DD:EE:FF",
                    onEscanear = { alvo = Alvo.MAC }
                )
            }

            CampoComScan(
                valor = serial,
                onChange = { serial = it },
                rotulo = if (ehChip) "ICCID do chip" else "Número de série (opcional)",
                dica = null,
                onEscanear = { alvo = Alvo.SERIAL }
            )

            CampoComScan(
                valor = contrato,
                onChange = { contrato = it },
                rotulo = "Número do contrato do cliente",
                dica = null,
                onEscanear = { alvo = Alvo.CONTRATO }
            )

            OutlinedTextField(
                value = obs,
                onValueChange = { obs = it },
                label = { Text("Observação (opcional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            erro?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Button(
                onClick = {
                    vm.salvar(
                        Equipamento(
                            id = inicial?.id ?: 0,
                            tipo = tipo,
                            mac = mac,
                            serial = serial,
                            contrato = contrato,
                            observacao = obs,
                            criadoEm = inicial?.criadoEm ?: System.currentTimeMillis()
                        ),
                        onErro = { erro = it },
                        onOk = onVoltar
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Salvar") }
        }
    }
}

@Composable
private fun CampoComScan(
    valor: String,
    onChange: (String) -> Unit,
    rotulo: String,
    dica: String?,
    onEscanear: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = valor,
            onValueChange = onChange,
            label = { Text(rotulo) },
            placeholder = dica?.let { { Text(it) } },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = onEscanear) { Text("Escanear") }
    }
}
