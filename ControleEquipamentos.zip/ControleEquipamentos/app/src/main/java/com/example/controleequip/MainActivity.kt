package com.example.controleequip

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.controleequip.data.Equipamento
import com.example.controleequip.ui.FormScreen
import com.example.controleequip.ui.ListaScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App(vm: EquipamentoViewModel = viewModel()) {
    var emFormulario by remember { mutableStateOf(false) }
    var editando by remember { mutableStateOf<Equipamento?>(null) }

    if (emFormulario) {
        FormScreen(
            vm = vm,
            inicial = editando,
            onVoltar = { emFormulario = false; editando = null }
        )
    } else {
        ListaScreen(
            vm = vm,
            onNovo = { editando = null; emFormulario = true },
            onEditar = { editando = it; emFormulario = true }
        )
    }
}
