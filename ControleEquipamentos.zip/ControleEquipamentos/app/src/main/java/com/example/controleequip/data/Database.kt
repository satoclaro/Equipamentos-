package com.example.controleequip.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

enum class TipoEquipamento(val rotulo: String) {
    EMTA("EMTA"),
    ONT("ONT"),
    DECODER("Decoder"),
    CHIP("Chip (SIM)"),
    OUTRO("Outro");

    companion object {
        fun de(nome: String): TipoEquipamento =
            entries.firstOrNull { it.name == nome } ?: OUTRO
    }
}

@Entity(tableName = "equipamentos")
data class Equipamento(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tipo: String = TipoEquipamento.EMTA.name,
    val mac: String = "",
    /** Número de série do equipamento ou ICCID, no caso de chip. */
    val serial: String = "",
    val contrato: String = "",
    val observacao: String = "",
    val criadoEm: Long = System.currentTimeMillis()
) {
    val tipoEnum: TipoEquipamento get() = TipoEquipamento.de(tipo)
}

@Dao
interface EquipamentoDao {
    @Query("SELECT * FROM equipamentos ORDER BY criadoEm DESC")
    fun todos(): Flow<List<Equipamento>>

    @Query("SELECT * FROM equipamentos ORDER BY criadoEm DESC")
    suspend fun todosAgora(): List<Equipamento>

    @Insert
    suspend fun inserir(e: Equipamento): Long

    @Update
    suspend fun atualizar(e: Equipamento)

    @Delete
    suspend fun excluir(e: Equipamento)

    @Query("SELECT COUNT(*) FROM equipamentos WHERE mac = :mac AND mac != '' AND id != :idAtual")
    suspend fun contarMac(mac: String, idAtual: Long): Int
}

@Database(entities = [Equipamento::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): EquipamentoDao

    companion object {
        @Volatile
        private var instancia: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instancia ?: synchronized(this) {
                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "equipamentos.db"
                ).build().also { instancia = it }
            }
    }
}
