package com.example.controleequip.util

object MacUtils {
    private val padroes = listOf(
        // AA:BB:CC:DD:EE:FF ou AA-BB-CC-DD-EE-FF
        Regex("(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{2}[:\\-]){5}[0-9A-Fa-f]{2}(?![0-9A-Fa-f])"),
        // aabb.ccdd.eeff
        Regex("(?<![0-9A-Fa-f])(?:[0-9A-Fa-f]{4}\\.){2}[0-9A-Fa-f]{4}(?![0-9A-Fa-f])"),
        // AABBCCDDEEFF (como vem na maioria das etiquetas)
        Regex("(?<![0-9A-Fa-f])[0-9A-Fa-f]{12}(?![0-9A-Fa-f])")
    )

    /**
     * Procura um MAC dentro do texto lido (aceita prefixos como "MAC:") e
     * devolve no formato AA:BB:CC:DD:EE:FF. Retorna null se não achar.
     */
    fun normalizar(texto: String): String? {
        val t = texto.trim()
        for (p in padroes) {
            val achado = p.find(t)?.value ?: continue
            return achado.filter { it.isLetterOrDigit() }
                .uppercase()
                .chunked(2)
                .joinToString(":")
        }
        return null
    }
}
