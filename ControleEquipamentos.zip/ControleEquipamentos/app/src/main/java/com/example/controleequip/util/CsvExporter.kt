package com.example.controleequip.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.example.controleequip.data.Equipamento
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {

    /** Gera o CSV (separador ";" e UTF-8 com BOM, abre direto no Excel pt-BR) e devolve a intent de compartilhar. */
    fun criarIntent(context: Context, lista: List<Equipamento>): Intent {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val arquivo = File(dir, "equipamentos.csv")
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

        arquivo.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("﻿")
            w.write("Tipo;MAC;Serial/ICCID;Contrato;Observacao;Data\n")
            lista.forEach { e ->
                w.write(
                    listOf(
                        e.tipoEnum.rotulo, e.mac, e.serial, e.contrato,
                        e.observacao, fmt.format(Date(e.criadoEm))
                    ).joinToString(";") { campo(it) }
                )
                w.write("\n")
            }
        }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", arquivo)
        val envio = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(envio, "Exportar equipamentos").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    private fun campo(s: String): String = "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""
}
