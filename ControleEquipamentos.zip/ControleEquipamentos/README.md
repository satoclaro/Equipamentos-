# Controle de Equipamentos

App Android (Kotlin + Jetpack Compose) para ler códigos de barras de etiquetas e guardar
**MAC**, **serial/ICCID** e **número de contrato do cliente** de equipamentos como
EMTA, ONT, decoders e chips.

## Como abrir e rodar
1. Instale o **Android Studio** (Koala ou mais recente).
2. `File > Open` e escolha a pasta `ControleEquipamentos`. O Android Studio baixa o Gradle e as dependências sozinho (precisa de internet na primeira vez).
3. Conecte um celular Android (depuração USB ligada) e clique em **Run ▶**.
   Para gerar o APK: `Build > Build Bundle(s) / APK(s) > Build APK(s)`.

Requisitos do aparelho: Android 7.0 (API 24) ou superior, com câmera.

## Como usar
- **Novo**: escolha o tipo (EMTA, ONT, Decoder, Chip, Outro) e use **Escanear** em cada campo.
- O MAC lido é convertido para o formato `AA:BB:CC:DD:EE:FF` (aceita `AABBCCDDEEFF`, `AA-BB-…`, `aabb.ccdd.eeff` e textos como `MAC: AABBCC…`).
- Para **Chip**, o campo MAC some e o ICCID (serial) passa a ser obrigatório.
- O contrato é obrigatório; o MAC não pode se repetir.
- Na lista há busca (MAC, contrato, serial, observação) e filtro por tipo. Toque em um item para editar.
- O botão de compartilhar exporta tudo em **CSV** (abre direto no Excel).

## Estrutura
- `data/Database.kt` – entidade, DAO e banco (Room)
- `util/MacUtils.kt` – extração e normalização de MAC
- `util/CsvExporter.kt` – exportação CSV
- `EquipamentoViewModel.kt` – validações e busca
- `ui/ScannerScreen.kt` – câmera (CameraX) + leitura (ML Kit, funciona offline)
- `ui/FormScreen.kt` / `ui/ListaScreen.kt` – telas

## Ideias para evoluir
Sincronizar com uma API/planilha online, ler vários códigos de uma etiqueta de uma vez, importar CSV, backup na nuvem, login por técnico.
